#!/bin/bash
# BotNET installation script.
# If this script causes problems, try "make all" instead.
# Usage: . install.sh

cc="/usr/bin/gcc"

echo "Compiling source code . . ."

bot=`$cc src/main.c src/launch.c src/memo.c src/seen.c src/parse.c src/help.c src/log.c src/info.c -o bin/bot -pthread || (echo 1)`
botnet=`$cc src/botserv.c -o bin/botserv || (echo 1)`

if [ "$bot" != "1" ]; then
	echo "Installation complete."
	echo "Executables will be found in bin/"
else
	echo "Errors encountered during compilation!"
fi
